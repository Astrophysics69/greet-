def greet():
    print("hello")